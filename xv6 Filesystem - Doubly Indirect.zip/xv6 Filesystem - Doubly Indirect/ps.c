
#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, const char * argv[])
{
    ps();
    exit();
}